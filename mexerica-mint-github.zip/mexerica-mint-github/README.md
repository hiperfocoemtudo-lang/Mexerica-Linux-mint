# 🍊 Mexerica — conversões com Shift + arrastar

Uma adaptação do [Mexerica](https://github.com/rogersocruz/mexerica), de Roger Augusto Souza da Cruz, para Linux Mint Cinnamon. Converta arquivos e acesse ferramentas por uma roda de opções em forma de gomos de laranja.

![Menu da Mexerica](docs/preview.png)

## Recursos

- Conversões de imagens, vídeos, áudios, PDFs e documentos.
- Compactação de pastas e arquivos em ZIP, 7Z e TAR.GZ.
- Ferramentas para recortar, redimensionar, comprimir, remover fundo e trabalhar com PDFs.
- Ações para copiar caminho, copiar ou mover arquivos, abrir terminal e fixar arquivos em uma janela.
- 18 composições de menu com 98 imagens de gomos individuais, fundo branco, brilho e animação de encaixe.
- Integração com o Nemo e inicialização automática.

## Compatibilidade

**Linux Mint 22 ou superior, Cinnamon e sessão X11.** A interface requer GTK 4.10 ou superior e usa o Python do sistema. O gesto global não funciona em Cinnamon Wayland. Esta distribuição não instala uma extensão do GNOME Shell.

## Instalação

No GitHub, clique em **Code → Download ZIP**, extraia o arquivo e abra a pasta extraída no terminal.

Para instalar o aplicativo e os conversores:

```bash
bash install.sh
```

Para incluir também a remoção de fundo por IA:

```bash
bash install.sh --with-background-removal
```

Execute como usuário normal. O instalador usa `sudo` para instalar dependências pelo APT, mas instala o aplicativo em `~/.local`. Dentro de uma sessão gráfica, ele encerra a instância anterior e inicia a versão nova. Se instalar fora da sessão gráfica, abra a Mexerica pelo menu de aplicativos depois.

Para adicionar a IA posteriormente:

```bash
bash install-background-removal.sh
```

A IA roda localmente. Na primeira utilização, pode ser necessário baixar o modelo. O complemento fica em um ambiente isolado gerenciado pelo `pipx`, sem instalar bibliotecas pelo `pip` no Python do sistema.

## Como usar

Comece a arrastar um arquivo ou pasta no Nemo e mantenha o modificador desejado pressionado:

| Atalho | Menu |
| --- | --- |
| Shift | Conversões |
| Shift + Alt | Ferramentas |
| Shift + Ctrl | Ações |

Passe sobre o gomo desejado e solte o botão do mouse para executar. É possível trocar de menu durante o mesmo arraste. Para cancelar, solte Shift ou solte o arquivo fora dos gomos. Após cancelar com Shift, inicie um novo arraste para abrir novamente.

As janelas das ferramentas podem ser redimensionadas arrastando as bordas ou os cantos. O conteúdo permite rolagem quando não couber na tela.

As opções também aparecem pelo botão direito do Nemo. **Fixar arquivo** abre uma pequena janela de onde é possível arrastar o arquivo para outro aplicativo.

## Dependências

### Interface e integração

| Dependência | Função |
| --- | --- |
| Python 3 | Executar o aplicativo; o Mint 22 fornece Python 3.12 |
| PyGObject (`python3-gi`) | Acesso às bibliotecas GTK/GNOME |
| Pycairo e integração GI (`python3-gi-cairo`, com `python3-cairo`) | Desenho da interface |
| GTK 4 e Gdk 4 (`gir1.2-gtk-4.0`) | Interface principal; GTK ≥ 4.10 |
| GTK 3 e Gdk 3 (`gir1.2-gtk-3.0`) | Leitura do arraste em processo separado |
| GLib, GObject, Gio, Pango e PangoCairo | Eventos, comunicação e desenho; instalados como dependências do GTK |
| Cinnamon, X11, `libX11` e uma sessão D-Bus | Detectar o gesto e integrar com o desktop |
| Nemo | Gerenciador de arquivos e menu de contexto |
| `adwaita-icon-theme` | Ícones da interface |
| `desktop-file-utils` | Atualizar o registro dos atalhos |
| Bash, APT, sudo, util-linux e coreutils | Scripts de instalação e inicialização; fornecidos pelo sistema |

### Conversores instalados pelo script principal

| Pacote | Programas e recursos |
| --- | --- |
| `ffmpeg` | `ffmpeg`, `ffprobe` e `ffplay`: vídeo, áudio, duração e prévia |
| `imagemagick` | `convert`/`magick` e `montage`: imagens e colagens |
| `poppler-utils` | `pdftoppm`, `pdftotext`, `pdfimages`, `pdfinfo`: leitura de PDFs |
| `qpdf` | Juntar, dividir e reorganizar PDFs |
| `ghostscript` | `gs`: compressão e processamento de PDFs |
| `libimage-exiftool-perl` | `exiftool`: metadados |
| `zbar-tools` | `zbarimg`: leitura de QR codes |
| `libarchive-tools` | `bsdtar`: arquivos compactados |
| `pandoc` | Conversões de texto, Markdown, EPUB e documentos |
| `libreoffice` | `soffice`/`libreoffice`: documentos, planilhas e apresentações |

O APT instala automaticamente as bibliotecas e codecs exigidos por esses pacotes. A disponibilidade de cada formato depende dos codecs, versões e políticas locais; por exemplo, o ImageMagick pode bloquear a escrita de PDF. O instalador não altera essa política.

### Remoção de fundo por IA — opcional

Requer `pipx`, `python3-venv` e **`rembg[cpu,cli]`**. Instalar apenas `rembg` pode deixar faltando o processamento por CPU ou a interface de linha de comando.

As dependências diretas do rembg com esses extras, na versão usada nesta adaptação, são:

- Núcleo: `jsonschema`, `numpy`, `Pillow`, `pooch`, `pymatting`, `scikit-image`, `scipy` e `tqdm`.
- Processamento por CPU: `onnxruntime`.
- Linha de comando: `aiohttp`, `asyncer`, `click`, `fastapi`, `filetype`, `gradio`, `python-multipart`, `sniffio`, `uvicorn` e `watchdog`.

O `pipx` resolve também as dependências transitivas. A [lista completa das 83 distribuições Python do ambiente de referência](docs/rembg-dependencias-referencia.txt) está incluída no projeto, com suas versões. Ela documenta o ambiente usado para validação; não é um arquivo de instalação obrigatório nem inclui os pacotes do sistema gerenciados pelo APT. Versões futuras do rembg podem alterar essa lista.

### Outros complementos opcionais

- `librsvg2-bin` (`rsvg-convert`): conversão dedicada de SVG; sem ele, há tentativa pelo ImageMagick.
- `typst`: geração de PDF em rotas de conversão do Pandoc que usem esse mecanismo.
- `xournalpp` (Xournal++): recursos de cadernos XOPP quando disponíveis.
- Um emulador de terminal e aplicativos associados aos arquivos: usados por “Terminal” e “Abrir”.

Esses complementos não são instalados automaticamente. CUDA e drivers NVIDIA não são necessários para o modo CPU configurado pelo instalador.

### Desenvolvimento

`python3-pytest` e `make` são usados nos testes, mas não são necessários para executar a interface.

```bash
sudo apt-get install python3-pytest make
make test
```

A suíte completa em `tests/` contém testes adicionais que dependem de conversores. A configuração do GitHub executa os testes unitários selecionados. Testes automatizados não substituem a conferência do gesto em Cinnamon X11.

## Atualizar, diagnosticar e desinstalar

Para atualizar, execute o instalador da nova versão. Se todas as dependências já estiverem presentes:

```bash
bash install.sh --no-deps
```

Para conferir os programas encontrados:

```bash
~/.local/bin/mexerica doctor
```

Para listar operações de um arquivo:

```bash
~/.local/bin/mexerica list "/caminho/arquivo.png"
```

Os registros ficam em `~/.cache/mexerica/mexerica.log`. Se as ações do Nemo não aparecerem após instalar, feche e reabra as janelas do gerenciador de arquivos; se necessário, entre novamente na sessão.

Para remover o aplicativo:

```bash
bash uninstall.sh
```

O desinstalador preserva o cache, os conversores do sistema e o rembg. Para remover também o complemento de IA instalado via pipx, use `pipx uninstall rembg` somente se ele não for usado por outros programas.

## Limitações e créditos

As artes prontas cobrem os menus principais. Seleções mistas ou operações adicionais podem usar o desenho de apoio. Ferramentas indisponíveis dependem da instalação dos conversores correspondentes.

Código sob licença MIT. Os créditos e o aviso de direitos autorais do projeto original estão preservados em [LICENSE](LICENSE) e [NOTICE.md](NOTICE.md).
