"""Ações recebem o arraste do Nemo e operam sobre todos os itens escolhidos."""
from types import SimpleNamespace
from zipfile import ZipFile

import pytest

from mexerica.app import Gdk, Gio, GLib, Gtk, MexericaApp, Overlay
from mexerica.engine import BY_ID, run
from mexerica.engine.ops import ACTIONS, CONVERT


@pytest.mark.parametrize("mode,offered,expected", [
    (ACTIONS, Gdk.DragAction.LINK, Gdk.DragAction.LINK),
    (ACTIONS, Gdk.DragAction.COPY, Gdk.DragAction.COPY),
    (ACTIONS, Gdk.DragAction.COPY | Gdk.DragAction.LINK, Gdk.DragAction.LINK),
    (CONVERT, Gdk.DragAction.COPY | Gdk.DragAction.MOVE, Gdk.DragAction.COPY),
    (CONVERT, Gdk.DragAction.MOVE, Gdk.DragAction(0)),
])
def test_drop_negotiation(mode, offered, expected):
    overlay = SimpleNamespace(state=SimpleNamespace(mode=mode))
    target = SimpleNamespace(get_current_drop=lambda: SimpleNamespace(
        get_actions=lambda: offered))
    assert Overlay._drop_action(overlay, target) == expected


@pytest.mark.parametrize("move", [False, True])
def test_copy_move_files_folders_and_collisions(tmp_path, monkeypatch, move):
    source, dest = tmp_path / "origem", tmp_path / "destino"
    source.mkdir()
    dest.mkdir()
    image = source / "foto.txt"
    image.write_text("arquivo original")
    folder = source / "pasta"
    folder.mkdir()
    (folder / "dentro.txt").write_text("conteúdo")
    (dest / image.name).write_text("não sobrescrever")
    (dest / folder.name).mkdir()
    notifications = []
    app = SimpleNamespace(notify=lambda *a, **kw: notifications.append(a))
    monkeypatch.setattr(GLib, "idle_add", lambda callback, *a: callback(*a))
    MexericaApp._copy_move(app, [image, folder], dest, move)
    assert (dest / "foto.txt").read_text() == "não sobrescrever"
    assert (dest / "foto (2).txt").read_text() == "arquivo original"
    assert (dest / "pasta (2)" / "dentro.txt").read_text() == "conteúdo"
    assert image.exists() is not move
    assert folder.exists() is not move
    assert notifications[0][1].startswith("Movido" if move else "Copiado")


@pytest.mark.parametrize("move", [False, True])
def test_copy_move_action_opens_folder_and_runs_selection(tmp_path, monkeypatch, move):
    calls = []
    class Dialog:
        @staticmethod
        def new(*args):
            calls.append(args)
            return dialog
        def set_current_folder(self, folder):
            assert folder.get_path() == str(tmp_path)
        def connect(self, signal, callback):
            self.response = callback
        def show(self):
            calls.append("shown")
        def get_file(self):
            return Gio.File.new_for_path(str(tmp_path / "destino"))
        def destroy(self):
            calls.append("closed")
    dialog = Dialog()
    monkeypatch.setattr(Gtk, "FileChooserNative", Dialog)
    class Worker:
        def __init__(self, target, args, daemon):
            self.target, self.args = target, args
        def start(self):
            self.target(*self.args)
    monkeypatch.setattr("mexerica.app.threading.Thread", Worker)
    app = SimpleNamespace(_copy_move=lambda *a: calls.append(a))
    app._choose_folder = lambda paths, move: MexericaApp._choose_folder(app, paths, move)
    paths = [tmp_path / "exemplo.txt"]
    op = BY_ID["act-move-to" if move else "act-copy-to"]
    MexericaApp._run_action(app, op, paths)
    assert calls[1] == "shown"
    assert app._folder_dialog is dialog
    dialog.response(dialog, Gtk.ResponseType.ACCEPT)
    assert calls[-1] == (paths, tmp_path / "destino", move)
    assert app._folder_dialog is None


def test_zip_action_includes_every_selection_and_keeps_archives(tmp_path):
    op = BY_ID["act-zip-all"]
    if not op.is_available():
        pytest.skip("bsdtar não instalado")
    other = tmp_path / "outro local"
    other.mkdir()
    first = tmp_path / "primeiro.txt"
    first.write_text("um")
    second = other / "segundo.txt"
    second.write_text("dois")
    folder = tmp_path / "pasta"
    folder.mkdir()
    (folder / "dentro.txt").write_text("três")
    archive = tmp_path / "existente.zip"
    with ZipFile(archive, "w") as z:
        z.writestr("interno.txt", "quatro")
    paths = [first, second, folder, archive]
    res = run(op, paths)
    assert res.ok, res.errors
    assert len(res.outputs) == 1
    with ZipFile(res.outputs[0]) as z:
        assert z.read("primeiro.txt") == b"um"
        assert z.read("segundo.txt") == b"dois"
        assert z.read("pasta/dentro.txt").decode() == "três"
        assert z.read("existente.zip") == archive.read_bytes()
        assert "interno.txt" not in z.namelist()
    assert all(path.exists() for path in paths)
