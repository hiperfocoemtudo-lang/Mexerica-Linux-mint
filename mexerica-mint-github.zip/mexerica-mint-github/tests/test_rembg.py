"""Erros de instalação do rembg devem orientar a correção em português."""
from pathlib import Path
import subprocess
import pytest
from mexerica.engine import ops


def test_missing_cpu_reports_repair_command(monkeypatch, tmp_path):
    monkeypatch.setattr(ops.T, 'has', lambda *_: True)
    monkeypatch.setattr(ops.T, 'cmd', lambda _: ['rembg'])
    monkeypatch.setattr(ops.subprocess, 'run', lambda *a, **kw:
                        subprocess.CompletedProcess(a, 1, b'', b'Please install rembg with CPU or GPU support'))
    ctx = ops.Ctx(tmp_path/'entrada.png', [], tmp_path, tmp_path/'saida.png')
    with pytest.raises(RuntimeError, match='install-background-removal.sh'):
        ops._remove_bg(ctx)[0](ctx)


def test_ai_success_preserves_paths_with_spaces(monkeypatch, tmp_path):
    monkeypatch.setattr(ops.T, 'has', lambda *_: True)
    monkeypatch.setattr(ops.T, 'cmd', lambda _: ['rembg'])
    src, dst = tmp_path/'minha imagem.png', tmp_path/'sem fundo.png'
    def run(argv, **kwargs):
        assert argv == ['rembg', 'i', str(src), str(dst)]
        dst.write_bytes(b'output')
        return subprocess.CompletedProcess(argv, 0, b'', b'')
    monkeypatch.setattr(ops.subprocess, 'run', run)
    ops._remove_bg(ops.Ctx(src, [src], tmp_path, dst))[0](ops.Ctx(src, [src], tmp_path, dst))
    assert dst.read_bytes() == b'output'
