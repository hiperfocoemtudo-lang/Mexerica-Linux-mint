"""A soltura continua funcionando após trocar de menu no mesmo arraste."""
from types import SimpleNamespace

import pytest

from mexerica.app import GLib, Overlay
from mexerica.desktop.cinnamon import CinnamonDesktop
from mexerica.desktop.drag import DragWatch
from mexerica.engine import options_for
from mexerica.engine.ops import ACTIONS, CONVERT, TOOLS
from mexerica.wheel.bitmap import configuration


@pytest.mark.parametrize("action", [
    "act-copy-path", "act-terminal", "act-copy-to", "act-move-to",
    "act-float", "act-zip-all",
])
@pytest.mark.parametrize("cancel", [None, "shift", "outside", "escape"])
def test_switch_menus_then_release_once(tmp_path, monkeypatch, action, cancel):
    source = tmp_path / "foto.png"
    source.write_bytes(b"test")
    calls, menus = [], []
    app = SimpleNamespace(execute=lambda op, paths: calls.append((op.id, paths)))
    overlay = SimpleNamespace(
        visible=False, paths=[], ops=[], app=app,
        area=SimpleNamespace(get_width=lambda: 800, get_height=lambda: 600),
        _ensure_wheel=lambda *a: None,
        _hover=lambda *a: None,
    )
    overlay.get_visible = lambda: overlay.visible
    overlay.close_wheel = lambda: setattr(overlay, "visible", False)
    overlay._hit = lambda wheel, x, y: (
        None if cancel == "outside" else
        next(i for i, op in enumerate(overlay.ops) if op.id == action))
    overlay.finish_drag = lambda x, y: Overlay.finish_drag(overlay, x, y)
    app.overlay = overlay
    def show(mode, paths):
        menus.append(mode)
        overlay.paths = list(paths)
        overlay.ops = configuration(options_for(paths, mode), mode)
        overlay.visible = True
    app.show_wheel = show
    app.hide_wheel = overlay.close_wheel
    desktop = CinnamonDesktop(app)
    desktop._watch = DragWatch()
    desktop._generation = 0
    desktop._paths = []
    desktop._anchor = None
    desktop._overlay_point = lambda ov, pt: pt
    desktop._read_files = lambda generation: setattr(desktop, "_paths", [source])
    class Reader:
        def __init__(self, target, args, daemon):
            self.target, self.args = target, args
        def start(self):
            self.target(*self.args)
    monkeypatch.setattr("mexerica.desktop.cinnamon.threading.Thread", Reader)
    monkeypatch.setattr(GLib, "idle_add", lambda callback, *a: callback(*a))
    samples = iter([
        (True, True, 1, (300, 300)),    # Shift: conversões
        (True, True, 5, (310, 300)),    # Ctrl depois da abertura
        (True, True, 9, (320, 300)),    # ferramentas no mesmo arraste
        (True, True, 5, (330, 300)),    # volta às ações
        (False, False, 0 if cancel == "shift" else 5, (340, 300)),
        (False, False, 5, (340, 300)),  # não repetir a execução
    ])
    desktop._x = SimpleNamespace(sample=lambda: next(samples))
    clock = iter(range(0, 180000, 30000))
    monkeypatch.setattr(GLib, "get_monotonic_time", lambda: next(clock))
    for i in range(6):
        if i == 4 and cancel == "escape":
            overlay.close_wheel()
        desktop._tick()
    assert menus == [CONVERT, ACTIONS, TOOLS, ACTIONS]
    assert calls == ([(action, [source])] if cancel is None else [])
    assert not overlay.get_visible()
    assert desktop._watch.shown is None
    assert desktop._anchor is None
