"""Combinações de arquivo precisam encontrar suas imagens individuais."""
from mexerica.engine import BY_ID
from mexerica.theme import wheel_label
from mexerica.wheel.bitmap import ROOT, _entry


def test_7z_conversion_has_three_image_sprites():
    operations = [BY_ID[key] for key in ('extract', 'pack-zip', 'pack-tar.gz')]
    entry = _entry([wheel_label(op) for op in operations])
    assert entry is not None, 'Menu 7z sem arte: cairia no desenho de apoio'
    assert len(entry['sprites']) == 3
    assert len(entry['anchors']) == len(entry['offsets']) == 3
    assert all((ROOT / sprite).is_file() for sprite in entry['sprites'])
