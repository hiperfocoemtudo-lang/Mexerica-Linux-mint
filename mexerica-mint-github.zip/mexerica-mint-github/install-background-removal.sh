#!/usr/bin/env bash
# Instala a IA local em ambiente isolado, sem modificar o Python do sistema.
set -euo pipefail
if [[ ${1:-} == --help || ${1:-} == -h ]]; then
    echo 'Uso: bash install-background-removal.sh (instala rembg com suporte CPU e CLI via pipx)'
    exit 0
fi
if (( EUID == 0 )); then echo 'Execute como usuário normal, sem sudo.' >&2; exit 1; fi
if ! command -v pipx >/dev/null; then
    sudo apt-get update
    sudo apt-get install -y pipx python3-venv
fi
if pipx runpip rembg show rembg >/dev/null 2>&1; then
    pipx runpip rembg install 'rembg[cpu,cli]'
else
    pipx install 'rembg[cpu,cli]'
fi
"$HOME/.local/bin/rembg" --help >/dev/null
printf '\nRemoção de fundo por IA instalada com suporte a CPU.\n'
printf 'Na primeira execução, o rembg pode baixar o modelo de IA.\n'
