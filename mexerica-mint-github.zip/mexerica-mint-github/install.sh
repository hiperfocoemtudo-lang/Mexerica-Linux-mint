#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if (( EUID == 0 )); then echo 'Execute como usuário normal, sem sudo.' >&2; exit 1; fi
install_deps=true
install_background=false
for option in "$@"; do
    case "$option" in
        --help|-h) echo 'Uso: bash install.sh [--no-deps] [--with-background-removal]'; exit 0 ;;
        --no-deps) install_deps=false ;;
        --with-background-removal) install_background=true ;;
        *) echo 'Opção inválida. Use --help.' >&2; exit 2 ;;
    esac
done
if "$install_deps"; then
    sudo apt-get update
    sudo apt-get install -y python3 python3-gi python3-gi-cairo gir1.2-gtk-4.0 gir1.2-gtk-3.0 desktop-file-utils adwaita-icon-theme nemo ffmpeg imagemagick poppler-utils qpdf ghostscript libimage-exiftool-perl zbar-tools libarchive-tools pandoc libreoffice
fi
/usr/bin/python3 - <<'PY'
import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gtk
if (Gtk.get_major_version(), Gtk.get_minor_version()) < (4, 10):
    raise SystemExit("Requer GTK 4.10 ou superior. Use Linux Mint 22 ou superior.")
PY
/usr/bin/python3 - <<'PY'
from pathlib import Path
import shutil
import shlex
import os
home = Path.home()
root = home / '.local/share/mexerica'
root.mkdir(parents=True, exist_ok=True)
shutil.copytree('mexerica', root / 'mexerica', dirs_exist_ok=True, ignore=shutil.ignore_patterns('__pycache__'))
bin = home / '.local/bin/mexerica'
bin.parent.mkdir(parents=True, exist_ok=True)
bin.write_text('#!/bin/sh\nexport GDK_BACKEND=x11\nexport PATH="$HOME/.local/bin:$PATH"\nexport PYTHONPATH=' + shlex.quote(str(root)) + '\nexec /usr/bin/python3 -m mexerica "$@"\n')
bin.chmod(0o755)
app = 'io.github.rogersocruz.Mexerica'
for src, dst in [('data/'+app+'.desktop', home/'.local/share/applications'/ (app+'.desktop')), ('data/'+app+'.service', home/'.local/share/dbus-1/services'/(app+'.service')), ('data/'+app+'-autostart.desktop',home/'.config/autostart'/(app+'.desktop'))]:
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_text(Path(src).read_text().replace('@BINDIR@/mexerica', '"'+str(bin)+'"'))
icon = home/'.local/share/icons/hicolor/scalable/apps'/(app+'.svg')
icon.parent.mkdir(parents=True, exist_ok=True)
shutil.copyfile('data/icons/'+app+'.svg', icon)
actions = home/'.local/share/nemo/actions'
actions.mkdir(parents=True, exist_ok=True)
for group, label in [('convert','Converter'), ('tools','Ferramentas'), ('actions','Ações')]:
    (actions/f'mexerica-{group}.nemo_action').write_text(f'[Nemo Action]\nName=Mexerica — {label}\nExec="{bin}" show --group {group} %U\nSelection=notnone\nExtensions=any;\nQuote=double\nIcon-Name={app}\n')
PY
if "$install_background"; then
    bash ./install-background-removal.sh
fi
gapplication action io.github.rogersocruz.Mexerica quit 2>/dev/null || true
update-desktop-database "$HOME/.local/share/applications" 2>/dev/null || true
if [[ -n ${DISPLAY:-} && -n ${DBUS_SESSION_BUS_ADDRESS:-} ]]; then
    setsid "$HOME/.local/bin/mexerica" --gapplication-service </dev/null >/dev/null 2>&1 &
fi
printf '\nMexerica instalada e iniciada nesta sessão gráfica.\n'
printf 'Se o menu do Nemo ainda não aparecer, feche e abra as janelas do gerenciador de arquivos.\n' 
