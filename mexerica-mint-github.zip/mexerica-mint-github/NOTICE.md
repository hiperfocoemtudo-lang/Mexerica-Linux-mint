# Créditos

Este projeto adapta o Mexerica, de Roger Augusto Souza da Cruz, para Linux Mint Cinnamon em X11. A licença MIT original está preservada em LICENSE.

Os menus desta adaptação usam imagens fornecidas e selecionadas pelo usuário e imagens geradas por IA durante o desenvolvimento. Nenhum arquivo de fonte tipográfica é distribuído.
