"""Leitor isolado GTK3: GTK3 e GTK4 não podem coexistir no mesmo processo."""
import sys
import gi

gi.require_version('Gtk', '3.0')
gi.require_version('Gdk', '3.0')
from gi.repository import Gdk, Gtk

if Gdk.Display.get_default() is None:
    raise SystemExit('Leitor XDND: não foi possível conectar ao display X11')

clipboard = Gtk.Clipboard.get(Gdk.Atom.intern('XdndSelection', False))
data = clipboard.wait_for_contents(Gdk.Atom.intern('text/uri-list', False))
if data is not None:
    raw = data.get_data()
    if raw:
        sys.stdout.buffer.write(raw)
