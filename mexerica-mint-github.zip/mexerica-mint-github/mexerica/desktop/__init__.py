"""Integração desta distribuição com Linux Mint Cinnamon."""
WINDOWS = False


def setup_process():
    pass


def backend(app):
    from .cinnamon import CinnamonDesktop
    return CinnamonDesktop(app)
