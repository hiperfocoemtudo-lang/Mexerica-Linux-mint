"""Cinnamon X11: detecta arrastes XDND sem capturar mouse ou teclado."""
import ctypes as C
import ctypes.util
import logging
import subprocess
import threading
from pathlib import Path
from gi.repository import Gdk, GLib
from .gnome import GnomeDesktop
from .drag import DragWatch, mode_for, SHOW

log = logging.getLogger('mexerica')

class XDrag:
    def __init__(self):
        self.x = C.CDLL(C.util.find_library('X11') or 'libX11.so.6')
        self.x.XOpenDisplay.argtypes = [C.c_char_p]
        self.x.XOpenDisplay.restype = C.c_void_p
        self.x.XDefaultRootWindow.argtypes = [C.c_void_p]
        self.x.XDefaultRootWindow.restype = C.c_ulong
        self.x.XInternAtom.argtypes = [C.c_void_p, C.c_char_p, C.c_int]
        self.x.XInternAtom.restype = C.c_ulong
        self.x.XGetSelectionOwner.argtypes = [C.c_void_p, C.c_ulong]
        self.x.XGetSelectionOwner.restype = C.c_ulong
        self.x.XQueryPointer.argtypes = [C.c_void_p, C.c_ulong,
            C.POINTER(C.c_ulong), C.POINTER(C.c_ulong),
            C.POINTER(C.c_int), C.POINTER(C.c_int), C.POINTER(C.c_int),
            C.POINTER(C.c_int), C.POINTER(C.c_uint)]
        self.x.XCloseDisplay.argtypes = [C.c_void_p]
        self.display = self.x.XOpenDisplay(None)
        if not self.display:
            raise RuntimeError('Não foi possível abrir o display X11')
        self.root = self.x.XDefaultRootWindow(self.display)
        self.selection = self.x.XInternAtom(self.display, b'XdndSelection', False)

    def sample(self):
        root, child = C.c_ulong(), C.c_ulong()
        rx, ry, wx, wy = C.c_int(), C.c_int(), C.c_int(), C.c_int()
        mask = C.c_uint()
        ok = self.x.XQueryPointer(self.display, self.root, C.byref(root),
            C.byref(child), C.byref(rx), C.byref(ry), C.byref(wx),
            C.byref(wy), C.byref(mask))
        owner = self.x.XGetSelectionOwner(self.display, self.selection)
        return bool(ok and mask.value & 256), bool(owner), mask.value, (rx.value, ry.value)

    def close(self):
        if self.display:
            self.x.XCloseDisplay(self.display)
            self.display = None

class CinnamonDesktop(GnomeDesktop):
    name = 'Cinnamon (X11)'
    overlay_dim = 0.0
    # O GTK perde o GdkDrop ao alternar Shift/Alt/Ctrl num arraste do Nemo.
    # Usamos os caminhos XDND já lidos e a transição do botão no X11.
    # Sem DropTarget, o Nemo cancela seu arraste: só a Mexerica modifica itens.
    handles_drag_release = True

    def start(self):
        import os
        self._watch = DragWatch()
        self._generation = 0
        self._paths = []
        self._anchor = None
        self._x = None
        if os.environ.get('XDG_SESSION_TYPE') == 'wayland':
            log.warning('Gesto Cinnamon requer sessão X11')
            return
        try:
            self._x = XDrag()
        except (OSError, RuntimeError) as exc:
            log.warning('Gesto indisponível: %s', exc)
            return
        self._poll = GLib.timeout_add(30, self._tick)
        self.app.connect('shutdown', self._shutdown)

    def _shutdown(self, *_):
        GLib.source_remove(self._poll)
        self._x.close()

    def _tick(self):
        button, owner, mods, pointer = self._x.sample()
        mode = mode_for(bool(mods & 1), bool(mods & 8), bool(mods & 4))
        if self._watch.shown and not mode:
            self._watch._hide()
            self._watch.given_up = True
            self.app.hide_wheel()
            self._anchor = None
        was_dragging = self._watch.dragging
        event = self._watch.step(button, owner, mode, pointer,
                                 GLib.get_monotonic_time() / 1000)
        if self._watch.dragging and not was_dragging:
            self._generation += 1
            self._paths = []
            threading.Thread(target=self._read_files,
                             args=(self._generation,), daemon=True).start()
        elif was_dragging and not self._watch.dragging:
            self._generation += 1
            overlay = self.app.overlay
            if self._watch.shown and mode and overlay and overlay.get_visible():
                x, y = self._overlay_point(overlay, pointer)
                log.info('soltura X11 no menu %s', self._watch.shown)
                overlay.finish_drag(x, y)
            self._watch._hide()
            self._anchor = None
        if event:
            if event[0] == SHOW:
                self._anchor = event[2]
                self.app.show_wheel(event[1], self._paths)
            else:
                self.app.hide_wheel()
                self._anchor = None
        overlay = self.app.overlay
        if button and self._watch.shown and overlay and overlay.get_visible():
            x, y = self._overlay_point(overlay, pointer)
            overlay._hover(x, y)
        return GLib.SOURCE_CONTINUE

    def _overlay_point(self, overlay, pointer):
        cx, cy = self.wheel_center(overlay, overlay.area.get_width(),
                                   overlay.area.get_height())
        scale = max(1, overlay.get_scale_factor())
        return (cx + (pointer[0] - self._anchor[0]) / scale,
                cy + (pointer[1] - self._anchor[1]) / scale)

    def _read_files(self, generation):
        try:
            result = subprocess.run(
                ['/usr/bin/python3', str(Path(__file__).with_name('read_xdnd.py'))],
                capture_output=True, timeout=3, check=True,
                env={**__import__('os').environ, 'GDK_BACKEND': 'x11'})
            uris = [line.strip() for line in result.stdout.decode('utf-8').splitlines()
                    if line.strip() and not line.startswith('#')]
            GLib.idle_add(self._files_ready, generation, uris)
        except subprocess.CalledProcessError as exc:
            log.warning('Leitor XDND falhou: %s', exc.stderr.decode('utf-8', errors='replace'))
        except (subprocess.SubprocessError, UnicodeError, OSError) as exc:
            log.warning('Não foi possível ler arquivos do arraste: %s', exc)

    def _files_ready(self, generation, uris):
        if generation != self._generation or not self._watch.dragging:
            return False
        from ..app import paths_from_uris
        self._paths = paths_from_uris(uris)
        if self._watch.shown and self._paths:
            self.app.show_wheel(self._watch.shown, self._paths)
        return False

    def show_overlay(self, win):
        super().show_overlay(win)
        GLib.idle_add(self._raise_overlay, win)

    def _raise_overlay(self, win):
        if not self._x or not win.get_visible():
            return False
        import gi
        gi.require_version('GdkX11', '4.0')
        from gi.repository import GdkX11
        surface = win.get_surface()
        if surface:
            import cairo
            surface.set_input_region(cairo.Region(cairo.RectangleInt(
                0, 0, surface.get_width(), surface.get_height())))
            xid = GdkX11.X11Surface.get_xid(surface)
            self._x.x.XRaiseWindow.argtypes = [C.c_void_p, C.c_ulong]
            self._x.x.XFlush.argtypes = [C.c_void_p]
            self._x.x.XRaiseWindow(self._x.display, xid)
            self._x.x.XFlush(self._x.display)
        return False

    def wheel_center(self, win, w, h):
        if self._anchor:
            surface = win.get_surface()
            if surface:
                import gi
                gi.require_version('GdkX11', '4.0')
                from gi.repository import GdkX11
                xid = GdkX11.X11Surface.get_xid(surface)
                x, y = C.c_int(), C.c_int()
                child = C.c_ulong()
                self._x.x.XTranslateCoordinates.argtypes = [C.c_void_p,
                    C.c_ulong, C.c_ulong, C.c_int, C.c_int,
                    C.POINTER(C.c_int), C.POINTER(C.c_int), C.POINTER(C.c_ulong)]
                self._x.x.XTranslateCoordinates(self._x.display, xid,
                    self._x.root, 0, 0, C.byref(x), C.byref(y), C.byref(child))
                scale = max(1, win.get_scale_factor())
                return ((self._anchor[0] - x.value) / scale,
                        (self._anchor[1] - y.value) / scale)
        return w / 2, h / 2

    def set_clipboard(self, text):
        display = Gdk.Display.get_default()
        if display:
            display.get_clipboard().set(text)

    def status(self):
        if self._x:
            return 'Gesto ativo: arraste arquivos e segure Shift (Alt: ferramentas; Ctrl: ações).'
        return 'Gesto indisponível. Entre numa sessão Cinnamon X11. Menu Nemo disponível.'
