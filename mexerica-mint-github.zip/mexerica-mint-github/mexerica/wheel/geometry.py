"""Geometria da roda radial (puro Python, sem GTK, testável).

Até 10 itens: um anel, e os setores dividem o círculo igualmente (4 itens =
90° cada). Mais que isso: os 10 primeiros no anel interno e o resto no
externo. O setor 0 fica centrado no topo e a ordem segue o sentido horário.
O miolo é a zona de cancelar. Medidas em theme.py, em função de R.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from .. import theme as TH

_R = TH.WHEEL_R
CANCEL_R = TH.CORE_RING_OUT * _R
RINGS = ((TH.SECTOR_IN * _R, TH.SECTOR_OUT * _R, TH.RING_CAPACITY[0]),
         (TH.OUTER_IN * _R, TH.OUTER_OUT * _R, TH.RING_CAPACITY[1]))
SLOP = TH.SLOP
MARGIN = TH.EDGE_MARGIN


@dataclass(frozen=True)
class Sector:
    index: int
    ring: int
    r_in: float
    r_out: float
    a0: float        # radianos, 0 = leste, sentido horário (y para baixo)
    a1: float

    @property
    def mid_angle(self) -> float:
        return (self.a0 + self.a1) / 2

    @property
    def mid_radius(self) -> float:
        return (self.r_in + self.r_out) / 2


class Wheel:
    def __init__(self, n_items: int, cx: float, cy: float,
                 width: float | None = None, height: float | None = None):
        self.n = max(0, min(n_items, sum(c for _, _, c in RINGS)))
        self.sectors = self._layout(self.n)
        self.radius = self.sectors[-1].r_out if self.sectors else RINGS[0][1]
        # aro: R com um anel; com dois, um pouco além do anel externo
        self.rim = _R if self.radius <= RINGS[0][1] \
            else self.radius + TH.RIM_PAD * _R
        self.cx, self.cy = self._clamp(cx, cy, width, height)

    @staticmethod
    def _layout(n: int) -> list[Sector]:
        sectors: list[Sector] = []
        remaining, idx = n, 0
        for ring, (r_in, r_out, cap) in enumerate(RINGS):
            count = min(remaining, cap)
            if count <= 0:
                break
            step = 2 * math.pi / count
            start = -math.pi / 2 - step / 2      # setor 0 centrado no topo
            for i in range(count):
                a0 = start + i * step
                sectors.append(Sector(idx, ring, r_in, r_out, a0, a0 + step))
                idx += 1
            remaining -= count
        return sectors

    def _clamp(self, cx, cy, w, h):
        r = self.rim + MARGIN
        if w is not None and w > 2 * r:
            cx = min(max(cx, r), w - r)
        if h is not None and h > 2 * r:
            cy = min(max(cy, r), h - r)
        return cx, cy

    def hit(self, x: float, y: float) -> int | None:
        """Índice do item sob (x, y); None no miolo ou longe da roda."""
        dx, dy = x - self.cx, y - self.cy
        dist = math.hypot(dx, dy)
        if dist < CANCEL_R or not self.sectors:
            return None
        ang = math.atan2(dy, dx)
        for s in self.sectors:
            if s.r_in <= dist <= s.r_out and _angle_in(ang, s.a0, s.a1):
                # As frestas entre gomos também cancelam.
                d0 = abs(math.sin(ang - s.a0) * dist)
                d1 = abs(math.sin(s.a1 - ang) * dist)
                if s.a1 - s.a0 >= 2 * math.pi - 1e-6 or min(d0, d1) >= TH.SECTOR_GAP / 2:
                    return s.index
        return None

    def in_cancel(self, x: float, y: float) -> bool:
        return math.hypot(x - self.cx, y - self.cy) < CANCEL_R


def _angle_in(a: float, a0: float, a1: float) -> bool:
    two_pi = 2 * math.pi
    a = (a - a0) % two_pi
    return a < (a1 - a0) or math.isclose(a, a1 - a0)
