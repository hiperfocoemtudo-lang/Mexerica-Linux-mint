"""Rodas pré-renderizadas; nenhuma composição de texto durante o uso."""
import json
from functools import lru_cache
from pathlib import Path
import cairo

ROOT = Path(__file__).resolve().parents[1] / 'assets' / 'wheels'
_cache = {}

@lru_cache(maxsize=1)
def _manifest():
    return json.loads((ROOT/'manifest.json').read_text())


def _entry(labels):
    entries=_manifest()
    return entries.get('|'.join(label.casefold() for label in labels))


def _sprites(entry):
    key=entry['file']
    if key not in _cache:
        result=[]
        for index,filename in enumerate(entry['sprites']):
            surface=cairo.ImageSurface.create_from_png(str(ROOT/filename))
            data=memoryview(surface.get_data()).cast('I')
            w,h=surface.get_width(),surface.get_height()
            anchor=entry['anchors'][index]
            result.append((surface,anchor,data,entry['offsets'][index]))
        _cache[key]=result
    return _cache[key]


def _entry_motion(index, anchor, width, height, center, progress):
    import math
    remaining=(1-max(0.0,min(1.0,progress)))**3
    dx,dy=anchor[0]-width*center[0],anchor[1]-height*center[1]
    length=max(1,math.hypot(dx,dy))
    # Distâncias diferentes e estáveis, sem mudar o destino final.
    distance=(36+(index*17)%47)*remaining
    rotation=(.055 if index%2 else -.055)*remaining
    return dx/length*distance,dy/length*distance,rotation


def _hover_strength(index, hover, values):
    value = (1.0 if index == hover else 0.0) if values is None else values.get(index, 0.0)
    value = max(0.0, min(1.0, value))
    return 1-(1-value)**3


def paint(cr,wheel,labels,hover,progress=1.0,hover_t=None):
    entry=_entry(labels)
    if not entry or not entry.get('sprites'):
        return False
    # Uma base branca por menu, separada das imagens interativas.
    import math
    cr.save()
    cr.arc(wheel.cx,wheel.cy,wheel.radius*.94,0,2*math.pi)
    cr.set_source_rgb(1,1,1)
    cr.fill()
    cr.restore()
    sprites=_sprites(entry)
    order=sorted(range(len(sprites)), key=lambda i: (i==hover, _hover_strength(i,hover,hover_t)))
    for index in order:
        surface,anchor,data,offset=sprites[index]
        lift=_hover_strength(index,hover,hover_t)
        w,h=surface.get_width(),surface.get_height()
        scale=wheel.radius/(640*entry.get('radius',.44))
        center=entry['center'];hot=lift>0
        import math
        ox,oy,rotation=_entry_motion(index,anchor,640,640,center,progress)
        cr.save()
        cr.translate(ox,oy)
        cr.translate(wheel.cx-640*center[0]*scale,wheel.cy-640*center[1]*scale)
        cr.scale(scale,scale)
        if rotation:
            cr.translate(anchor[0],anchor[1])
            cr.rotate(rotation)
            cr.translate(-anchor[0],-anchor[1])
        if hot:
            cr.translate(anchor[0],anchor[1]);cr.scale(1+.18*lift,1+.18*lift);cr.translate(-anchor[0],-anchor[1])
        if hot:
            # Sombra da própria imagem, pintada antes dela e acima dos outros gomos.
            cr.save()
            for dx,dy in ((0,3),(-2,3),(2,3),(0,5),(-1,4),(1,4)):
                cr.set_source_rgba(0,0,0,.035*lift)
                cr.mask_surface(surface,offset[0]+dx/scale,offset[1]+dy/scale)
            cr.restore()
        cr.set_source_surface(surface,*offset);cr.paint()
        if hot:
            cr.set_operator(cairo.OPERATOR_ADD)
            cr.set_source_surface(surface,*offset);cr.paint_with_alpha(.28*lift)
        cr.restore()
    return True


def hit(wheel,labels,x,y,progress=1.0,hover=None,hover_t=None):
    entry=_entry(labels)
    if not entry or not entry.get('sprites'):
        return wheel.hit(x,y)
    center=entry['center']
    # Testar os pixels das próprias imagens, sem dividir por quadrantes.
    sprites=_sprites(entry)
    order=sorted(range(len(sprites)),key=lambda i:(i==hover,_hover_strength(i,hover,hover_t)),reverse=True)
    for index in order:
        surface,anchor,data,offset=sprites[index]
        w,h=surface.get_width(),surface.get_height()
        scale=wheel.radius/(640*entry.get('radius',.44))
        import math
        ox,oy,rotation=_entry_motion(index,anchor,640,640,center,progress)
        px=(x-wheel.cx-ox)/scale+640*center[0]
        py=(y-wheel.cy-oy)/scale+640*center[1]
        grow=1+.18*_hover_strength(index,hover,hover_t)
        dx,dy=(px-anchor[0])/grow,(py-anchor[1])/grow
        px=round(anchor[0]+math.cos(rotation)*dx+math.sin(rotation)*dy)-offset[0]
        py=round(anchor[1]-math.sin(rotation)*dx+math.cos(rotation)*dy)-offset[1]
        # Pequena tolerância para antialias e espaços estreitos entre letras.
        for dy in range(-5,6):
            for dx in range(-5,6):
                xx,yy=px+dx,py+dy
                if 0<=xx<w and 0<=yy<h and data[yy*w+xx]>>24>100:
                    return index
    return None


def configuration(ops, group):
    """Escolher apenas artes cujo mapa contenha todos os comandos atuais."""
    path = ROOT / 'catalog.json'
    if not path.exists():
        return ops
    from ..engine import BY_ID
    current = {op.id for op in ops}
    candidates = [entry for entry in json.loads(path.read_text()).values()
                  if entry['group'] == group and current and current <= set(entry['ids'])
                  and (ROOT / 'gomos' / Path(entry['file']).stem).is_dir()]
    if not candidates:
        return ops
    entry = min(candidates, key=lambda item: len(item['ids']))
    return [BY_ID[key] for key in entry['ids']]


def bind_geometry(wheel, labels):
    import math
    from .geometry import Sector
    entries = _manifest()
    entry = entries.get('|'.join(label.casefold() for label in labels), {})
    regions = entry.get('regions')
    if not regions:
        return
    result=[]
    for index,(start,end) in enumerate(regions):
        original=wheel.sectors[index]
        end=start+((end-start)%360 or 360)
        result.append(Sector(index,original.ring,original.r_in,original.r_out,
                             math.radians(start),math.radians(end)))
    wheel.sectors=result


def warm_up():
    for entry in _manifest().values():
        if entry.get('sprites'):
            _sprites(entry)
