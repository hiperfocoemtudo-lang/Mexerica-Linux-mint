"""Composição dos gomos em PNG e fallback para combinações adicionais."""
from __future__ import annotations
from dataclasses import dataclass, field
from .geometry import Wheel

@dataclass
class Snapshot:
    """Conteúdo de uma roda, para o crossfade ao trocar de modo."""
    wheel: Wheel
    labels: list[str]
    icons: list[str | None]


@dataclass
class WheelState:
    mode: str = "convert"
    labels: list[str] = field(default_factory=list)
    icons: list[str | None] = field(default_factory=list)
    hints: list[str] = field(default_factory=list)
    caption: str = ""               # miolo sem hover: "1.1 MB"
    hover: int | None = None
    cancel_hover: bool = False
    loading: bool = False
    progress: float = 1.0           # entrada 0..1 (linear; a curva é aqui)
    hover_t: dict[int, float] = field(default_factory=dict)  # 0..1 por setor
    fade: float = 1.0               # troca de modo 0..1
    prev: Snapshot | None = None    # conteúdo anterior, sumindo



def _sectors(cr, wheel, labels, icons, hover_t, progress=1.0):
    from .bitmap import paint
    hover = max(hover_t, key=hover_t.get) if hover_t else None
    if hover is not None and hover_t[hover] < .1:
        hover = None
    if not paint(cr, wheel, labels, hover, progress, hover_t):
        from .legacy_render import _sectors as fallback
        fallback(cr, wheel, labels, icons, hover_t)


def draw(cr, wheel: Wheel, st: WheelState) -> None:
    if wheel.sectors:
        _sectors(cr, wheel, st.labels, st.icons, st.hover_t, st.progress)
