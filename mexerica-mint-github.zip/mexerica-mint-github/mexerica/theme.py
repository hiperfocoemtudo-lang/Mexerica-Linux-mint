"""Tema visual: vidro fosco claro e quente (referência: Tangerine).

Toda cor, medida e duração da interface mora aqui. Cores são tuplas RGB(A)
de 0 a 1 para o cairo; a versão em hex fica no comentário e no CSS.
"""
from __future__ import annotations

import sys


def _hex(h: str, a: float = 1.0) -> tuple[float, float, float, float]:
    h = h.lstrip("#")
    return (int(h[0:2], 16) / 255, int(h[2:4], 16) / 255,
            int(h[4:6], 16) / 255, a)


def rgba255(r: int, g: int, b: int, a: float) -> tuple[float, ...]:
    return (r / 255, g / 255, b / 255, a)


# --------------------------------------------------------------------------
# Paleta
# --------------------------------------------------------------------------
ORANGE = "#FF5A1F"                 # ação primária, hover, alças
ORANGE_DEEP = "#FD4D02"            # fim do gradiente de hover
ORANGE_RING = "#F79241"            # anel do miolo
ORANGE_PILL = "#FDC375"            # pílula do miolo
TEXT = "#3A2A20"                   # texto em repouso (marrom quase preto)
TEXT_SOFT = "#8A4A10"              # miolo, botões planos, opções inativas
WHITE = "#FFFFFF"
WINDOW_TOP = "#FFB45A"             # gradiente das janelas
WINDOW_BOTTOM = "#FF8A4C"
WINDOW_ALPHA = 0.92

# --------------------------------------------------------------------------
# Roda (medidas em função de R, o raio externo)
# --------------------------------------------------------------------------
WHEEL_R = 195.0
SECTOR_IN = 0.12                   # faixa dos setores: 0,42R a 0,92R
SECTOR_OUT = 0.92
OUTER_IN = 0.98                    # 2º anel (mais de 10 itens)
OUTER_OUT = 1.44
RIM_PAD = 0.08                     # aro além do último anel
CORE_RING_IN = 0.30                # anel laranja do miolo
CORE_RING_OUT = 0.10
CORE_PILL_W = 0.62
CORE_PILL_H = 0.24
RING_CAPACITY = (10, 16)
SECTOR_GAP = 5.0                   # px, constante ao longo do arco
SECTOR_CORNER = 24.0               # px, cantos das pílulas anelares
HOVER_GROW = 0.012                  # setor em hover cresce 2% para fora
SLOP = 48.0                        # tolerância além do aro que ainda seleciona
EDGE_MARGIN = 12.0                 # distância mínima da borda da tela

RIM_FILL = rgba255(255, 246, 236, 0.35)     # branco quente ~35%
RIM_STROKE = rgba255(255, 255, 255, 0.60)
RIM_STROKE_W = 1.5
CORE_RING = _hex(ORANGE_RING, 0.70)
CORE_PILL = _hex(ORANGE_PILL)
SECTOR_TOP = rgba255(255, 132, 0, 1.0)   # repouso: mais claro no topo
SECTOR_BOTTOM = rgba255(255, 187, 111, 1.0)
SECTOR_EDGE = rgba255(255, 255, 255, 0.55)
HOVER_TOP = _hex("#FFD180")
HOVER_BOTTOM = _hex("#FF9800")
SHADOW = rgba255(120, 40, 0, 0.18)
SHADOW_BLUR = 24.0
SHADOW_DY = 6.0

LABEL_COLOR = _hex("#5C2900")
LABEL_HOVER = _hex(WHITE)
LABEL_PX = 11.0
LABEL_MIN_PX = 8.0                 # encolhe até aqui antes de quebrar linha
LABEL_WEIGHT = 700
LABEL_TRACKING = 0.5               # px
CORE_COLOR = _hex(TEXT_SOFT)
CORE_PX = 10.0
CORE_WEIGHT = 600
ICON_PX = 16.0
ICON_GAP = 3.0
ICON_STROKE = 1.5
FONT_FAMILY = "Inter, Cantarell, Segoe UI, Sans"

# Movimento (ms)
ENTER_MS = 230
ENTER_SCALE = 0.92
HOVER_MS = 80
MODE_FADE_MS = 120

# --------------------------------------------------------------------------
# Rótulos e ícones da roda (os ids das operações não mudam)
# --------------------------------------------------------------------------
LABELS = {
    "img-edit": "Editar", "img-crop": "Recortar", "img-size": "Tamanho",
    "img-addbg": "Pôr fundo", "img-rmbg": "Tirar fundo",
    "img-compress": "Comprimir", "img-rotate": "Girar", "img-qr": "Ler QR",
    "img-pdf": "Para PDF", "img-collage": "Colagem",
    "vid-trim": "Cortar", "vid-size": "Tamanho", "vid-compress": "Comprimir",
    "vid-mute": "Sem áudio", "vid-2x": "Velocidade 2×", "vid-rotate": "Girar",
    "vid-snap": "Capturar", "vid-join": "Juntar",
    "aud-trim": "Cortar", "aud-normalize": "Normalizar", "aud-compress": "Comprimir",
    "aud-mono": "Mono", "aud-silence": "Silêncio", "aud-join": "Juntar",
    "pdf-pages": "Páginas", "pdf-compress": "Comprimir", "pdf-split": "Separar",
    "pdf-rotate": "Girar", "pdf-images": "Imagens", "pdf-merge": "Juntar",
    "strip-meta": "Limpar dados", "show-meta": "Metadados",
    "act-copy-path": "Copiar caminho", "act-terminal": "Terminal",
    "act-copy-to": "Copiar para", "act-move-to": "Mover para", "act-float": "Fixar arquivo",
    "act-zip-all": "ZIP", "extract": "Extrair",
}

ICONS = {
    "img-edit": "sliders", "img-crop": "crop", "img-size": "resize",
    "img-addbg": "image", "img-rmbg": "eraser",
    "img-compress": "compress", "img-rotate": "rotate",
    "img-qr": "qr", "img-pdf": "doc", "img-collage": "grid",
    "vid-trim": "scissors", "vid-size": "resize", "vid-compress": "compress",
    "vid-mute": "mute", "vid-2x": "speed", "vid-rotate": "rotate",
    "vid-snap": "camera", "vid-join": "merge",
    "aud-trim": "scissors", "aud-normalize": "wave", "aud-compress": "compress",
    "aud-mono": "wave", "aud-silence": "wave", "aud-join": "merge",
    "pdf-pages": "pages", "pdf-compress": "compress", "pdf-split": "split",
    "pdf-rotate": "rotate", "pdf-images": "image", "pdf-merge": "merge",
    "strip-meta": "eye-off", "show-meta": "tag",
    "act-copy-path": "link", "act-terminal": "terminal",
    "act-copy-to": "copy", "act-move-to": "move", "act-float": "pin",
    "act-zip-all": "archive",
}


def wheel_label(op) -> str:
    return LABELS.get(op.id, op.label).upper()


def wheel_icon(op) -> str | None:
    """Ícone de linha; a roda de conversão não usa ícones."""
    return ICONS.get(op.id) if op.group != "convert" else None


def human_size(n: int) -> str:
    """Tamanho como no Finder (base 1000): 1.1 MB."""
    if n < 1000:
        return f"{n} B"
    for unit in ("KB", "MB", "GB", "TB"):
        n /= 1000
        if n < 1000 or unit == "TB":
            return f"{n:.1f} {unit}" if n < 100 else f"{n:.0f} {unit}"
    return ""


# --------------------------------------------------------------------------
# Janelas de edição
# --------------------------------------------------------------------------
# No Windows 11 o DWM arredonda a janela com 8 px e o vidro (borrão) segue
# esse contorno, então o CSS usa o mesmo raio.
WINDOW_RADIUS = 8 if sys.platform == "win32" else 16
HANDLE_PX = 8                      # alças quadradas do recorte
CROP_DIM = rgba255(60, 60, 60, 0.55)
CROP_LINE = rgba255(255, 255, 255, 0.95)
HANDLE = _hex(ORANGE)
SWATCH_PX = 22
SWATCH_RADIUS = 6

# Add BG: 9 gradientes (quentes e frios) e 9 sólidas
BG_GRADIENTS: list[tuple[str, str]] = [
    ("#FF9A5A", "#FF4E50"), ("#F6D365", "#FDA085"), ("#FBC2EB", "#A6C1EE"),
    ("#FF7EB3", "#FF758C"), ("#F093FB", "#F5576C"), ("#4FACFE", "#00F2FE"),
    ("#43E97B", "#38F9D7"), ("#667EEA", "#764BA2"), ("#30CFD0", "#330867"),
]
BG_SOLIDS: list[str] = [
    "#FFFFFF", "#FFD60A", "#C6F432", "#34C759", "#30B0A7", "#32ADE6",
    "#0A84FF", "#1C2C5B", "#AF52DE",
]
BG_PADDING = (0, 1000, 100)        # min, max, padrão (px da imagem)
BG_CORNERS = (0, 300, 104)
BG_SHADOW = (0, 100, 24)
BG_RATIOS: list[tuple[str, float | None]] = [
    ("Auto", None), ("1:1", 1.0), ("16:9", 16 / 9), ("4:5", 4 / 5),
]

CSS = """
/* Base clara e gomos laranja: mesma identidade da roda. */
window.mx-window {
  background: #ffffff;
  color: #342719;
  border: 1px solid #f0dcc3;
  border-radius: 24px;
  font-family: "DejaVu Sans", Sans;
  font-size: 13px;
}
window.mx-window > * { border-radius: 24px; }
.mx-header { padding: 20px 22px 18px; border-bottom: 1px solid #f5ebdf; }
.mx-brand { color: #e97900; font-weight: 800; font-size: 10px; }
.mx-title { font-family: "Kavoon", "DejaVu Sans", Sans; font-weight: 400; font-size: 21px; color: #e97900; }
window.mx-window button {
  background: #fff7ec; color: #49321c; border: 1px solid #f0e0ca;
  border-radius: 14px; box-shadow: none; padding: 7px 12px;
  font-weight: 600;
}
window.mx-window button:hover { background: #ffeed5; border-color: #ffc16c; }
window.mx-window button.mx-close {
  min-width: 30px; min-height: 30px; padding: 0; border-radius: 99px;
  background: #fff2df; color: #b85800; border: none; font-size: 17px;
}
window.mx-window button.mx-close:hover { background: #ffe2b7; }
.mx-footer { padding: 18px 22px 20px; border-top: 1px solid #f5ebdf; }
window.mx-window button.mx-flat { background: none; border-color: transparent; color: #8d6440; border-radius: 99px; }
window.mx-window button.mx-flat:hover { background: #fff3e2; }
window.mx-window button.mx-primary {
  background: linear-gradient(180deg, #ff9e14, #ff7c00);
  color: white; font-weight: 700; border: none;
  border-radius: 99px; padding: 10px 24px;
  box-shadow: 0 3px 8px alpha(#a74a00, 0.18);
}
window.mx-window button.mx-primary:hover { background: linear-gradient(180deg, #ffad30, #ff8900); }
window.mx-window button.mx-primary:disabled { background: #ffe1b8; color: #b78349; box-shadow: none; }
.mx-label { color: #49321c; font-weight: 600; font-size: 13px; }
.mx-dim { color: #8d7862; font-size: 12px; }
.mx-value { color: #8d6440; font-size: 12px; font-feature-settings: "tnum"; min-width: 48px; }
.mx-error { color: #bd3f1b; font-size: 12px; font-weight: 600; }
.mx-segmented { background: #fff1dc; border-radius: 99px; padding: 4px; }
window.mx-window .mx-segmented button {
  background: none; color: #91663e; border: none; box-shadow: none;
  border-radius: 99px; padding: 7px 13px; margin: 1px; font-size: 12px;
}
window.mx-window .mx-segmented button:checked { background: #ff8b00; color: white; }
window.mx-window entry, window.mx-window spinbutton, window.mx-window dropdown > button {
  background: #fff8ef; color: #49321c; border: 1px solid #efdfca;
  border-radius: 13px; min-height: 30px; box-shadow: none;
}
window.mx-window entry:focus { border-color: #ffa12b; }
window.mx-window popover > contents { background: white; color: #49321c; border-radius: 14px; border: 1px solid #efdfca; }
window.mx-window listview, window.mx-window list { background: white; color: #49321c; }
window.mx-window listview row:selected, window.mx-window list row:selected { background: #fff0d9; color: #9b4a00; }
window.mx-window scale trough { background: #f2e8dc; min-height: 5px; border-radius: 99px; }
window.mx-window scale highlight { background: #ff950d; border-radius: 99px; }
window.mx-window scale slider { background: white; min-width: 17px; min-height: 17px; margin: -6px; border-radius: 99px; border: 2px solid #ff990f; box-shadow: 0 2px 4px alpha(#a75400, .12); }
window.mx-window checkbutton check, window.mx-window switch { background: #f4e9db; border: 1px solid #e8d8c2; }
window.mx-window checkbutton check { border-radius: 6px; }
window.mx-window checkbutton check:checked, window.mx-window switch:checked { background: #ff9100; color: white; border-color: #ff9100; }
window.mx-window switch slider { background: white; }
window.mx-window scrolledwindow, window.mx-window viewport, window.mx-window flowbox { background: none; }
window.mx-window textview, window.mx-window textview text { background: white; color: #342719; }
.mx-canvas { background: #faf7f2; border-radius: 18px; }
.mx-frame { background: #f4ede3; border-radius: 14px; }
window.mx-window button.mx-swatch { min-width: 22px; min-height: 22px; padding: 0; border-radius: 6px; border: 2px solid transparent; box-shadow: inset 0 0 0 1px alpha(black, .08); }
window.mx-window button.mx-swatch.selected { border-color: #ff8c00; box-shadow: 0 0 0 2px #ffe3b5; }
window.mx-window button.mx-pill { border-radius: 99px; padding: 5px 12px; font-size: 12px; }
window.mx-window headerbar { background: white; box-shadow: none; border: none; color: #e97900; }
window.mx-window button.mx-page { padding: 7px; border-radius: 14px; background: #faf6f0; border: 2px solid transparent; }
window.mx-window button.mx-page:checked { background: #fff0d8; border-color: #ff9500; }
"""

# A moldura nativa oferece as alças de redimensionamento. As duas partes
# brancas são recortadas pelos próprios widgets para evitar cantos quadrados.
CSS += """
window.mx-window { background: transparent; border: none; }
window.mx-window > * { border-radius: 0; }
window.mx-window .mx-titlebar { background: white; border-radius: 20px 20px 0 0; }
window.mx-window .mx-shell { background: white; border-radius: 0 0 20px 20px; }
window.mx-window .mx-header { border-radius: 20px 20px 0 0; }
"""
