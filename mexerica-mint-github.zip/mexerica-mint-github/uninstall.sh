#!/usr/bin/env bash
set -euo pipefail
if (( EUID == 0 )); then echo 'Execute sem sudo.' >&2; exit 1; fi
gapplication action io.github.rogersocruz.Mexerica quit 2>/dev/null || true
rm -rf -- "$HOME/.local/share/mexerica"
rm -f -- "$HOME/.local/bin/mexerica" "$HOME/.local/share/applications/io.github.rogersocruz.Mexerica.desktop" "$HOME/.local/share/dbus-1/services/io.github.rogersocruz.Mexerica.service" "$HOME/.config/autostart/io.github.rogersocruz.Mexerica.desktop" "$HOME/.local/share/icons/hicolor/scalable/apps/io.github.rogersocruz.Mexerica.svg"
for group in convert tools actions; do rm -f -- "$HOME/.local/share/nemo/actions/mexerica-$group.nemo_action"; done
printf 'Mexerica removida. As dependências compartilhadas foram mantidas.\n'
